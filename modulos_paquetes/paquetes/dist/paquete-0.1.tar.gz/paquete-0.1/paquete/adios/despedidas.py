# Un modulo
# Este es un modulo con funciones que despiden 
def despedirse():
	print("Adios, te estoy despidiendo desde la funcion del modulo despedidas.")

class Despedida():
	def __init__(self):
		print("Adios, te despido desde el init de la clase Despedida")
		