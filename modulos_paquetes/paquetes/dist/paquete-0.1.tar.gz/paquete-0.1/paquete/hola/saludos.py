# Un modulo
# Este es un modulo con funciones que saludan 
def saludar():
	print("Hola, te estoy saludando desde la funcion del modulo saludo.")

class Saludo():
	def __init__(self):
		print("Hola, te saludo desde el init de la clase saludo")
		